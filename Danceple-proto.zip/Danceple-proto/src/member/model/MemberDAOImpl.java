package member.model;

import com.ibatis.sqlmap.client.SqlMapClient;

import dandb.UserVO;
import ibatis.QueryHandler;

public class MemberDAOImpl implements MemberDAO {

	private static MemberDAOImpl memberDAO = null;
	
	public static MemberDAOImpl getInstance() {
		if (memberDAO == null) {
			memberDAO = new MemberDAOImpl();
		}
		return memberDAO;
	}

	@Override
	public void insertMember(UserVO userVO) throws Exception {
		SqlMapClient sqlMap = QueryHandler.getInstance();
		sqlMap.insert("user.insertUser",userVO);

	}

	@Override // 유저사용자인증확인
	public int userCheck(UserVO userVO) throws Exception {
		int result = -1;
		String pwd = null;
		
		SqlMapClient sqlMap = QueryHandler.getInstance();
		pwd = (String) sqlMap.queryForObject("user.userCheck", userVO.getUserId());
		
			if (pwd != null) {
				if (pwd.equals(userVO.getUserPwd())) {
					result = 1;

				} else {
					result = 0;
				}
			} else {
				result = -1;
			}
			
		return result;
	}

	@Override
	public UserVO getUser(UserVO userVO) throws Exception {

		SqlMapClient sqlMap = QueryHandler.getInstance();
		return (UserVO) sqlMap.queryForObject("user.getUser", userVO.getUserId());
	}

}

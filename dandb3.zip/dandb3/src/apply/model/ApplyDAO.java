package apply.model;

import dandb.ApplyVO;

public interface ApplyDAO {
	void insertApply(ApplyVO applyVO) throws Exception;
	
}

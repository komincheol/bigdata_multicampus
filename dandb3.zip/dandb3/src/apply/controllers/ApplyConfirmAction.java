package apply.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import basic.controllers.AbstractController;
import basic.controllers.ModelAndView;

public class ApplyConfirmAction extends AbstractController{
@Override
public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) {
	// TODO Auto-generated method stub
	return null;
}
}

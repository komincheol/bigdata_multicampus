package member.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import basic.controllers.AbstractController;
import basic.controllers.ModelAndView;
import dandb.MemberVO;
import member.model.MemberDAO;
import member.model.MemberDAOImpl;

public class LoginAction extends AbstractController{

	@Override
	public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) {
		String memberId= request.getParameter("memberId");
		String memberPwd= request.getParameter("memberPwd");
		int result= -1;
		
		MemberVO mVO= new MemberVO();
		mVO.setUserId(memberId);
		mVO.setUserPwd(memberPwd);
		
		MemberDAO memberDAO = MemberDAOImpl.getInstance();
		ModelAndView mav= new ModelAndView("/WEB-INF/member/result.jsp");
		
		try {			
			result=memberDAO.userCheck(mVO);
			if(result==1){
				mVO= memberDAO.getMember(mVO);
				
			}
			mav.addObject("msg","로그인 성공.");
			mav.addObject("url","main");
		} catch (Exception e) {
			mav.addObject("msg","로그인 실패");
			mav.addObject("url", "javascript:history.back();");
		}
		return mav;
	}

}
